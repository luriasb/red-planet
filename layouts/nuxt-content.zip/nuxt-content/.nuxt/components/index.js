export { default as Hello } from '../../components/global/Hello.vue'
export { default as PageFooter } from '../../components/global/PageFooter.vue'
export { default as PageHeader } from '../../components/global/PageHeader.vue'
export { default as PageHero } from '../../components/global/PageHero.vue'
export { default as ParaImage } from '../../components/global/ParaImage.vue'
export { default as Feature01 } from '../../components/global/feature/Feature01.vue'
export { default as Footer01 } from '../../components/global/footers/Footer01.vue'
export { default as Header1 } from '../../components/global/headers/Header1.vue'
export { default as Header2 } from '../../components/global/headers/Header2.vue'
export { default as Header3 } from '../../components/global/headers/Header3.vue'
export { default as Header4 } from '../../components/global/headers/Header4.vue'
export { default as Hero01 } from '../../components/global/heroes/Hero01.vue'
export { default as HeroA01 } from '../../components/global/heroes/HeroA01.vue'
export { default as Navigation01 } from '../../components/global/navigations/Navigation01.vue'
export { default as Step01 } from '../../components/global/steps/Step01.vue'
export { default as Quiz01 } from '../../components/global/quizzes/Quiz01.vue'
export { default as TypographyBlack } from '../../components/global/styles/TypographyBlack.vue'
export { default as TypographyBlack2 } from '../../components/global/styles/TypographyBlack2.vue'
export { default as Logo } from '../../components/Logo.vue'

export const LazyHello = import('../../components/global/Hello.vue' /* webpackChunkName: "components/global/Hello" */).then(c => c.default || c)
export const LazyPageFooter = import('../../components/global/PageFooter.vue' /* webpackChunkName: "components/global/PageFooter" */).then(c => c.default || c)
export const LazyPageHeader = import('../../components/global/PageHeader.vue' /* webpackChunkName: "components/global/PageHeader" */).then(c => c.default || c)
export const LazyPageHero = import('../../components/global/PageHero.vue' /* webpackChunkName: "components/global/PageHero" */).then(c => c.default || c)
export const LazyParaImage = import('../../components/global/ParaImage.vue' /* webpackChunkName: "components/global/ParaImage" */).then(c => c.default || c)
export const LazyFeature01 = import('../../components/global/feature/Feature01.vue' /* webpackChunkName: "components/global/feature/Feature01" */).then(c => c.default || c)
export const LazyFooter01 = import('../../components/global/footers/Footer01.vue' /* webpackChunkName: "components/global/footers/Footer01" */).then(c => c.default || c)
export const LazyHeader1 = import('../../components/global/headers/Header1.vue' /* webpackChunkName: "components/global/headers/Header1" */).then(c => c.default || c)
export const LazyHeader2 = import('../../components/global/headers/Header2.vue' /* webpackChunkName: "components/global/headers/Header2" */).then(c => c.default || c)
export const LazyHeader3 = import('../../components/global/headers/Header3.vue' /* webpackChunkName: "components/global/headers/Header3" */).then(c => c.default || c)
export const LazyHeader4 = import('../../components/global/headers/Header4.vue' /* webpackChunkName: "components/global/headers/Header4" */).then(c => c.default || c)
export const LazyHero01 = import('../../components/global/heroes/Hero01.vue' /* webpackChunkName: "components/global/heroes/Hero01" */).then(c => c.default || c)
export const LazyHeroA01 = import('../../components/global/heroes/HeroA01.vue' /* webpackChunkName: "components/global/heroes/HeroA01" */).then(c => c.default || c)
export const LazyNavigation01 = import('../../components/global/navigations/Navigation01.vue' /* webpackChunkName: "components/global/navigations/Navigation01" */).then(c => c.default || c)
export const LazyStep01 = import('../../components/global/steps/Step01.vue' /* webpackChunkName: "components/global/steps/Step01" */).then(c => c.default || c)
export const LazyQuiz01 = import('../../components/global/quizzes/Quiz01.vue' /* webpackChunkName: "components/global/quizzes/Quiz01" */).then(c => c.default || c)
export const LazyTypographyBlack = import('../../components/global/styles/TypographyBlack.vue' /* webpackChunkName: "components/global/styles/TypographyBlack" */).then(c => c.default || c)
export const LazyTypographyBlack2 = import('../../components/global/styles/TypographyBlack2.vue' /* webpackChunkName: "components/global/styles/TypographyBlack2" */).then(c => c.default || c)
export const LazyLogo = import('../../components/Logo.vue' /* webpackChunkName: "components/Logo" */).then(c => c.default || c)
