import Vue from 'vue'

const globalComponents = {
  Hello: () => import('../../components/global/Hello.vue' /* webpackChunkName: "components/global/Hello" */).then(c => c.default || c),
  PageFooter: () => import('../../components/global/PageFooter.vue' /* webpackChunkName: "components/global/PageFooter" */).then(c => c.default || c),
  PageHeader: () => import('../../components/global/PageHeader.vue' /* webpackChunkName: "components/global/PageHeader" */).then(c => c.default || c),
  PageHero: () => import('../../components/global/PageHero.vue' /* webpackChunkName: "components/global/PageHero" */).then(c => c.default || c),
  ParaImage: () => import('../../components/global/ParaImage.vue' /* webpackChunkName: "components/global/ParaImage" */).then(c => c.default || c),
  Feature01: () => import('../../components/global/feature/Feature01.vue' /* webpackChunkName: "components/global/feature/Feature01" */).then(c => c.default || c),
  Footer01: () => import('../../components/global/footers/Footer01.vue' /* webpackChunkName: "components/global/footers/Footer01" */).then(c => c.default || c),
  Header1: () => import('../../components/global/headers/Header1.vue' /* webpackChunkName: "components/global/headers/Header1" */).then(c => c.default || c),
  Header2: () => import('../../components/global/headers/Header2.vue' /* webpackChunkName: "components/global/headers/Header2" */).then(c => c.default || c),
  Header3: () => import('../../components/global/headers/Header3.vue' /* webpackChunkName: "components/global/headers/Header3" */).then(c => c.default || c),
  Header4: () => import('../../components/global/headers/Header4.vue' /* webpackChunkName: "components/global/headers/Header4" */).then(c => c.default || c),
  Hero01: () => import('../../components/global/heroes/Hero01.vue' /* webpackChunkName: "components/global/heroes/Hero01" */).then(c => c.default || c),
  HeroA01: () => import('../../components/global/heroes/HeroA01.vue' /* webpackChunkName: "components/global/heroes/HeroA01" */).then(c => c.default || c),
  Navigation01: () => import('../../components/global/navigations/Navigation01.vue' /* webpackChunkName: "components/global/navigations/Navigation01" */).then(c => c.default || c),
  Step01: () => import('../../components/global/steps/Step01.vue' /* webpackChunkName: "components/global/steps/Step01" */).then(c => c.default || c),
  Quiz01: () => import('../../components/global/quizzes/Quiz01.vue' /* webpackChunkName: "components/global/quizzes/Quiz01" */).then(c => c.default || c),
  TypographyBlack: () => import('../../components/global/styles/TypographyBlack.vue' /* webpackChunkName: "components/global/styles/TypographyBlack" */).then(c => c.default || c),
  TypographyBlack2: () => import('../../components/global/styles/TypographyBlack2.vue' /* webpackChunkName: "components/global/styles/TypographyBlack2" */).then(c => c.default || c)
}

for (const name in globalComponents) {
  Vue.component(name, globalComponents[name])
}
