import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _ce8ddbec = () => interopDefault(import('../pages/bementoree.vue' /* webpackChunkName: "pages/bementoree" */))
const _683200a8 = () => interopDefault(import('../pages/calculator.vue' /* webpackChunkName: "pages/calculator" */))
const _326d61ef = () => interopDefault(import('../pages/examples.vue' /* webpackChunkName: "pages/examples" */))
const _03910d9c = () => interopDefault(import('../pages/hello.vue' /* webpackChunkName: "pages/hello" */))
const _0364003e = () => interopDefault(import('../pages/landing.vue' /* webpackChunkName: "pages/landing" */))
const _5e832954 = () => interopDefault(import('../pages/sections.vue' /* webpackChunkName: "pages/sections" */))
const _1c222c55 = () => interopDefault(import('../pages/typography.vue' /* webpackChunkName: "pages/typography" */))
const _e7c9c4c8 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/bementoree",
    component: _ce8ddbec,
    name: "bementoree"
  }, {
    path: "/calculator",
    component: _683200a8,
    name: "calculator"
  }, {
    path: "/examples",
    component: _326d61ef,
    name: "examples"
  }, {
    path: "/hello",
    component: _03910d9c,
    name: "hello"
  }, {
    path: "/landing",
    component: _0364003e,
    name: "landing"
  }, {
    path: "/sections",
    component: _5e832954,
    name: "sections"
  }, {
    path: "/typography",
    component: _1c222c55,
    name: "typography"
  }, {
    path: "/",
    component: _e7c9c4c8,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
