/*
** TailwindCSS Configuration File
**
** Docs: https://tailwindcss.com/docs/configuration
** Default: https://github.com/tailwindcss/tailwindcss/blob/master/stubs/defaultConfig.stub.js
*/
module.exports = {
  theme: {
    extend: {
      fontFamily: {
        // 'display': ['Source Sans Pro', 'sans-serif'],
        // 'body': ['Sintony', 'sans-serif'],
        'display': ['Open Sans', 'sans-serif'],
        'body': ['Open Sans', 'sans-serif'],
      },
      colors: {
        "link": '#F4933C',
        'black2': '#222A41'
      },
      fontSize: {
        '7xl': '5rem',
        '8xl': '6rem',
      }
    },
  },
  variants: {
    opacity: ['responsive', 'hover', 'focus', 'disabled']
  },
  plugins: [
  ],
  purge: {
    // Learn more on https://tailwindcss.com/docs/controlling-file-size/#removing-unused-css
    enabled: process.env.NODE_ENV === 'production',
    content: [
      'components/**/*.vue',
      'layouts/**/*.vue',
      'pages/**/*.vue',
      'plugins/**/*.js',
      'nuxt.config.js'
    ]
  }
}
