<template>
  <div class="container mx-auto mt-10">
    <div class="bg-white shadow rounded-lg p-6">
      <div class="grid lg:grid-cols-2 gap-6">
        <div
          class="border focus-within:border-blue-500 focus-within:text-blue-500 transition-all duration-500 relative rounded p-1"
        >
          <div class="-mt-4 absolute tracking-wider px-1 uppercase text-xs">
            <p>
              <label
                for="initial"
                class="bg-white text-gray-600 px-1"
              >Aportación inicial *</label
              >
            </p>
          </div>
          <p>
            <input
              id="initial"
              v-model.number="s0"
              autocomplete="false"
              tabindex="0"
              type="text"
              class="py-1 px-1 text-gray-900 outline-none block h-full w-full"
            />
          </p>
        </div>
        <div
          class="border focus-within:border-blue-500 focus-within:text-blue-500 transition-all duration-500 relative rounded p-1"
        >
          <div class="-mt-4 absolute tracking-wider px-1 uppercase text-xs">
            <p>
              <label
                for="recurrent"
                class="bg-white text-gray-600 px-1"
              >Aportación recurrente *</label
              >
            </p>
          </div>
          <p>
            <input
              id="recurrent"
              v-model.number="x"
              autocomplete="false"
              tabindex="0"
              type="text"
              class="py-1 px-1 outline-none block h-full w-full"
            />
          </p>
        </div>
        <div
          class="border focus-within:border-blue-500 focus-within:text-blue-500 transition-all duration-500 relative rounded p-1"
        >
          <div class="-mt-4 absolute tracking-wider px-1 uppercase text-xs">
            <p>
              <label
                for="periodType"
                class="bg-white text-gray-600 px-1"
              >Selecciona un periodo *</label
              >
            </p>
          </div>
          <p>
            <!-- <input id="username" autocomplete="false" tabindex="0" type="text" class="py-1 px-1 outline-none block h-full w-full"> -->
            <select
              name="periodType"
              id="periodType"
              class="py-1 px-1 outline-none block h-full w-full"
              v-model="periodType"
            >
              <option value=""></option>
              <option value="weekly">Semanal</option>
              <option value="biweekly">Quincenal</option>
              <option value="monthly">Mensual</option>
              <option value="annually">Anual</option>
            </select>
          </p>
        </div>
        <div
          class="border focus-within:border-blue-500 focus-within:text-blue-500 transition-all duration-500 relative rounded p-1"
        >
          <div class="-mt-4 absolute tracking-wider px-1 uppercase text-xs">
            <p>
              <label
                for="number-periods"
                class="bg-white text-gray-600 px-1"
              >Número de años *</label
              >
            </p>
          </div>
          <p>
            <input
              id="number-periods"
              v-model.number="years"
              autocomplete="false"
              tabindex="0"
              type="text"
              class="py-1 px-1 outline-none block h-full w-full"
            />
          </p>
        </div>
      </div>
      <div class="border-t mt-6 pt-3">
        <!-- <button
          class="rounded text-gray-100 px-3 py-1 bg-blue-500 hover:shadow-inner hover:bg-blue-700 transition-all duration-300"
        >
          Calculate
        </button> -->
        <p>
          <span class="font-bold"> Total: </span> {{ total }}
        </p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      s0: 0,
      x: 0,
      periodType: '',
      n: 0,
      years: 0,
      anualRate: 0.05000
    }
  },
  computed: {
    realNumPeriods () {
      if (!this.years) { return 0 }
      let periods = 0
      switch (this.periodType) {
        case 'weekly':
          periods = 52
          break
        case 'biweekly':
          periods = 26
          break
        case 'monthly':
          periods = 12
          break
        case 'annually':
          periods = 1
          break
        default:
          break
      }
      return this.years * periods
    },
    rate () {
      let periods = 0
      switch (this.periodType) {
        case 'weekly':
          periods = 52
          break
        case 'biweekly':
          periods = 26
          break
        case 'monthly':
          periods = 12
          break
        case 'annually':
          periods = 1
          return this.anualRate
        default:
          return 0
      }
      return (Math.pow(1 + this.anualRate, 1 / periods)) - 1
    },
    total () {
      return Math.round(this.partOne + this.partTwo)
    },
    partOne () {
      if (!this.rate) { return 0 }
      return this.x * ((Math.pow(1 + this.rate, this.realNumPeriods + 1) - (1 + this.rate)) / (this.rate))
    },
    partTwo () {
      return (this.s0 * Math.pow(1 + this.rate, this.realNumPeriods))
    }
  },
  methods: {
  }
}
</script>

<style></style>
