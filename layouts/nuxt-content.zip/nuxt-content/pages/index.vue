<template>
  <article>
    <nuxt-content :document="currentPage" />
  </article>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  layout: 'courseLayout',
  async asyncData ({ $content, store }) {
    const page = await $content('course').fetch()
    const pages = await $content('sections').sortBy('index').fetch()
    store.commit('pagination/bootstrapPages', pages)
    // eslint-disable-next-line
    console.log(page)
    return {
      page,
      pages
    }
  },
  computed: {
    ...mapGetters('pagination', [
      'currentPage'
    ])
  }
}
</script>
<style >
</style>
