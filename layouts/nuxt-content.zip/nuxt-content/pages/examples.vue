<template>
  <div class="w-full">
    <section
      id="features"
      class="box-border block leading-6 m-0 px-0 py-24 relative text-left text-gray-700 md:px-0 md:py-16"
    >
      <div
        class="container leading-6 my-0 mx-auto py-0 px-4 text-gray-700 w-full"
      >
        <div
          class="box-border flex flex-wrap justify-center my-0 -mx-4 p-0 text-left"
        >
          <div
            class="md:flex-grow-0 md:flex-shrink-0 lg:flex-grow-0 lg:flex-shrink-0 flex-grow-0 flex-shrink-0 leading-6 m-0 max-w-full py-0 px-4 relative text-gray-700 w-full"
            style="flex-basis: 100%; quotes: auto;"
          >
            <!-- Section Heading -->
            <div
              class="leading-6 m-0 max-w-full py-0 px-4 relative text-left text-gray-700 w-full"
              style="flex-basis: 100%; quotes: auto;"
            >
              <!-- Section Heading -->
              <div class="leading-6 mx-0 mt-0 mb-20 p-0 text-center" style="quotes: auto;">
                <h2
                  class="box-border text-3xl m-0 relative"
                >
                  Explore Premium Features
                </h2>
                <p
                  class="box-border leading-normal mb-0 mt-6 text-center text-base"
                >
                  Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum
                  obcaecati dignissimos quae quo ad iste ipsum officiis deleniti asperiores
                  sit.
                </p>
              </div>
            </div>

          </div>
        </div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <div
          class="box-border flex flex-wrap my-0 -mx-4 p-0 text-left"
          style="quotes: auto;"
        >
          <div
            class="md:flex-grow-0 md:flex-shrink-0 lg:flex-grow-0 lg:flex-shrink-0 flex-grow-0 flex-shrink-0 leading-6 m-0 max-w-full py-0 px-4 relative text-gray-700 w-full"
            style="flex-basis: 100%; quotes: auto;"
          >
            <!-- Icon Box -->
            <div
              class="box-border m-0 p-6 text-center visible"
              data-wow-duration="2s"
              style="visibility: visible; animation-duration: 2s; animation-name: fadeInUp; quotes: auto;"
            >
              <!-- Featured Icon -->
              <div
                class="leading-6 mx-0 mt-0 mb-4 p-0 text-gray-700"
                style="quotes: auto;"
              >
                <span
                  class="box-border text-xl my-0 mr-0 ml-5 text-center not-italic"
                  style="font-family: Flaticon; line-height: 1.2; quotes: auto;"
                ></span>
              </div>
              <!-- Icon Text -->
              <div class="leading-6 p-0 text-gray-700" style="quotes: auto;">
                <h3
                  class="box-border text-3xl leading-normal mx-0 mt-0 mb-2 text-center"
                  style="font-weight: var(--h3-weight); quotes: auto;"
                >
                  Fully functional
                </h3>
                <p
                  class="box-border leading-normal m-0 text-center"
                  style="font-weight: var(--p-weight); quotes: auto;"
                >
                  Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                  Veritatis culpa expedita dignissimos.
                </p>
              </div>
            </div>
          </div>
          <div
            class="md:flex-grow-0 md:flex-shrink-0 lg:flex-grow-0 lg:flex-shrink-0 flex-grow-0 flex-shrink-0 leading-6 m-0 max-w-full py-0 px-4 relative text-gray-700 w-full"
            style="flex-basis: 100%; quotes: auto;"
          >
            <!-- Icon Box -->
            <div
              class="box-border m-0 p-6 text-center visible"
              data-wow-duration="2s"
              data-wow-delay="0.2s"
              style="visibility: visible; animation-duration: 2s; animation-delay: 0.2s; animation-name: fadeInUp; quotes: auto;"
            >
              <!-- Featured Icon -->
              <div
                class="leading-6 mx-0 mt-0 mb-4 p-0 text-gray-700"
                style="quotes: auto;"
              >
                <span
                  class="box-border text-xl my-0 mr-0 ml-5 text-center not-italic"
                  style="font-family: Flaticon; line-height: 1.2; quotes: auto;"
                ></span>
              </div>
              <!-- Icon Text -->
              <div class="leading-6 p-0 text-gray-700" style="quotes: auto;">
                <h3
                  class="box-border text-3xl leading-normal mx-0 mt-0 mb-2 text-center"
                  style="font-weight: var(--h3-weight); quotes: auto;"
                >
                  Fully functional
                </h3>
                <p
                  class="box-border leading-normal m-0 text-center"
                  style="font-weight: var(--p-weight); quotes: auto;"
                >
                  Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                  Veritatis culpa expedita dignissimos.
                </p>
              </div>
            </div>
          </div>
          <div
            class="md:flex-grow-0 md:flex-shrink-0 lg:flex-grow-0 lg:flex-shrink-0 flex-grow-0 flex-shrink-0 leading-6 m-0 max-w-full py-0 px-4 relative text-gray-700 w-full"
            style="flex-basis: 100%; quotes: auto;"
          >
            <!-- Icon Box -->
            <div
              class="box-border m-0 p-6 text-center visible"
              data-wow-duration="2s"
              data-wow-delay="0.4s"
              style="visibility: visible; animation-duration: 2s; animation-delay: 0.4s; animation-name: fadeInUp; quotes: auto;"
            >
              <!-- Featured Icon -->
              <div
                class="leading-6 mx-0 mt-0 mb-4 p-0 text-gray-700"
                style="quotes: auto;"
              >
                <span
                  class="box-border text-xl my-0 mr-0 ml-5 text-center not-italic"
                  style="font-family: Flaticon; line-height: 1.2; quotes: auto;"
                ></span>
              </div>
              <!-- Icon Text -->
              <div class="leading-6 p-0 text-gray-700" style="quotes: auto;">
                <h3
                  class="box-border text-3xl leading-normal mx-0 mt-0 mb-2 text-center"
                  style="font-weight: var(--h3-weight); quotes: auto;"
                >
                  Fully functional
                </h3>
                <p
                  class="box-border leading-normal m-0 text-center"
                  style="font-weight: var(--p-weight); quotes: auto;"
                >
                  Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                  Veritatis culpa expedita dignissimos.
                </p>
              </div>
            </div>
          </div>
          <div
            class="md:flex-grow-0 md:flex-shrink-0 lg:flex-grow-0 lg:flex-shrink-0 flex-grow-0 flex-shrink-0 leading-6 m-0 max-w-full py-0 px-4 relative text-gray-700 w-full"
            style="flex-basis: 100%; quotes: auto;"
          >
            <!-- Icon Box -->
            <div
              class="box-border m-0 p-6 text-center visible"
              data-wow-duration="2s"
              data-wow-delay="0.6s"
              style="visibility: visible; animation-duration: 2s; animation-delay: 0.6s; animation-name: fadeInUp; quotes: auto;"
            >
              <!-- Featured Icon -->
              <div
                class="leading-6 mx-0 mt-0 mb-4 p-0 text-gray-700"
                style="quotes: auto;"
              >
                <span
                  class="box-border text-xl my-0 mr-0 ml-5 text-center not-italic"
                  style="font-family: Flaticon; line-height: 1.2; quotes: auto;"
                ></span>
              </div>
              <!-- Icon Text -->
              <div class="leading-6 p-0 text-gray-700" style="quotes: auto;">
                <h3
                  class="box-border text-3xl leading-normal mx-0 mt-0 mb-2 text-center"
                  style="font-weight: var(--h3-weight); quotes: auto;"
                >
                  Location Tracking
                </h3>
                <p
                  class="box-border leading-normal m-0 text-center"
                  style="font-weight: var(--p-weight); quotes: auto;"
                >
                  Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                  Veritatis culpa expedita dignissimos.
                </p>
              </div>
            </div>
          </div>
          <div
            class="md:flex-grow-0 md:flex-shrink-0 lg:flex-grow-0 lg:flex-shrink-0 flex-grow-0 flex-shrink-0 leading-6 m-0 max-w-full py-0 px-4 relative text-gray-700 w-full"
            style="flex-basis: 100%; quotes: auto;"
          >
            <!-- Icon Box -->
            <div
              class="box-border m-0 p-6 text-center visible"
              data-wow-duration="2s"
              data-wow-delay="0.8s"
              style="visibility: visible; animation-duration: 2s; animation-delay: 0.8s; animation-name: fadeInUp; quotes: auto;"
            >
              <!-- Featured Icon -->
              <div
                class="leading-6 mx-0 mt-0 mb-4 p-0 text-gray-700"
                style="quotes: auto;"
              >
                <span
                  class="box-border text-xl my-0 mr-0 ml-5 text-center not-italic"
                  style="font-family: Flaticon; line-height: 1.2; quotes: auto;"
                ></span>
              </div>
              <!-- Icon Text -->
              <div class="leading-6 p-0 text-gray-700" style="quotes: auto;">
                <h3
                  class="box-border text-3xl leading-normal mx-0 mt-0 mb-2 text-center"
                  style="font-weight: var(--h3-weight); quotes: auto;"
                >
                  Powerful Settings
                </h3>
                <p
                  class="box-border leading-normal m-0 text-center"
                  style="font-weight: var(--p-weight); quotes: auto;"
                >
                  Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                  Veritatis culpa expedita dignissimos.
                </p>
              </div>
            </div>
          </div>
          <div
            class="md:flex-grow-0 md:flex-shrink-0 lg:flex-grow-0 lg:flex-shrink-0 flex-grow-0 flex-shrink-0 leading-6 m-0 max-w-full py-0 px-4 relative text-gray-700 w-full"
            style="flex-basis: 100%; quotes: auto;"
          >
            <!-- Icon Box -->
            <div
              class="box-border m-0 p-6 text-center visible"
              data-wow-duration="2s"
              data-wow-delay="1s"
              style="visibility: visible; animation-duration: 2s; animation-delay: 1s; animation-name: fadeInUp; quotes: auto;"
            >
              <!-- Featured Icon -->
              <div
                class="leading-6 mx-0 mt-0 mb-4 p-0 text-gray-700"
                style="quotes: auto;"
              >
                <span
                  class="box-border text-xl my-0 mr-0 ml-5 text-center not-italic"
                  style="font-family: Flaticon; line-height: 1.2; quotes: auto;"
                ></span>
              </div>
              <!-- Icon Text -->
              <div class="leading-6 p-0 text-gray-700" style="quotes: auto;">
                <h3
                  class="box-border text-3xl leading-normal mx-0 mt-0 mb-2 text-center"
                  style="font-weight: var(--h3-weight); quotes: auto;"
                >
                  Multiple Language
                </h3>
                <p
                  class="box-border leading-normal m-0 text-center"
                  style="font-weight: var(--p-weight); quotes: auto;"
                >
                  Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                  Veritatis culpa expedita dignissimos.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section
      class="box-border block leading-6 m-0 overflow-hidden px-0 py-24 relative text-left text-gray-700 md:px-0 md:py-16"
      style="quotes: auto;"
    >
      <div
        class="leading-6 my-0 mx-auto py-0 px-4 text-gray-700 w-full"
        style="quotes: auto;"
      >
        <div
          class="box-border flex flex-wrap justify-between my-0 -mx-4 p-0 text-left"
          style="quotes: auto;"
        >
          <div
            class="lg:flex-grow-0 lg:flex-shrink-0 lg:order-1 flex-grow-0 flex-shrink-0 order-2 leading-6 m-0 max-w-full py-0 px-4 relative text-gray-700 w-full"
            style="flex-basis: 100%; quotes: auto;"
          >
            <!-- Service Text -->
            <div
              class="lg:pt-0 box-border m-0 px-0 pb-0 pt-6 text-left"
              style="quotes: auto;"
            >
              <h2
                class="text-3xl mx-0 mt-0 mb-6 p-0"
                style="font-weight: var(--h2-weight); line-height: 1.3; quotes: auto;"
              >
                Share your photos with friends easily
              </h2>
              <!-- Service List -->
              <ul class="leading-6 p-0 text-gray-700" style="quotes: auto;">
                <!-- Single Service -->
                <li
                  class="box-border flex items-start m-0 px-0 py-2 text-left"
                  style="list-style: none; quotes: auto;"
                >
                  <div
                    class="leading-6 py-0 pl-0 pr-6 text-gray-700"
                    style="list-style: outside none none; quotes: auto;"
                  >
                    <span
                      class="rounded box-border inline-block h-12 text-2xl m-0 p-0 shadow-xs text-center w-12"
                      style="line-height: 2.25; transition: all 0.3s ease 0s; list-style: outside none none; quotes: auto;"
                      ><svg
                        class="inline-block h-4 overflow-visible text-center text-purple-600 w-3"
                        aria-hidden="true"
                        focusable="false"
                        data-prefix="fab"
                        data-icon="buffer"
                        role="img"
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 448 512"
                        data-fa-i2svg=""
                        style="vertical-align: -0.125em; line-height: 54px; list-style: outside none none; quotes: auto;"
                      >
                        <path
                          fill="currentColor"
                          d="M427.84 380.67l-196.5 97.82a18.6 18.6 0 0 1-14.67 0L20.16 380.67c-4-2-4-5.28 0-7.29L67.22 350a18.65 18.65 0 0 1 14.69 0l134.76 67a18.51 18.51 0 0 0 14.67 0l134.76-67a18.62 18.62 0 0 1 14.68 0l47.06 23.43c4.05 1.96 4.05 5.24 0 7.24zm0-136.53l-47.06-23.43a18.62 18.62 0 0 0-14.68 0l-134.76 67.08a18.68 18.68 0 0 1-14.67 0L81.91 220.71a18.65 18.65 0 0 0-14.69 0l-47.06 23.43c-4 2-4 5.29 0 7.31l196.51 97.8a18.6 18.6 0 0 0 14.67 0l196.5-97.8c4.05-2.02 4.05-5.3 0-7.31zM20.16 130.42l196.5 90.29a20.08 20.08 0 0 0 14.67 0l196.51-90.29c4-1.86 4-4.89 0-6.74L231.33 33.4a19.88 19.88 0 0 0-14.67 0l-196.5 90.28c-4.05 1.85-4.05 4.88 0 6.74z"
                          class="box-border text-2xl m-0 p-0 text-purple-600"
                          style="line-height: 2.25; list-style: outside none none; quotes: auto;"
                        ></path></svg
                      ><!-- <i class="fab fa-buffer"></i> --></span
                    >
                  </div>
                  <div
                    class="flex-1 leading-6 p-0 text-gray-700"
                    style="list-style: outside none none; quotes: auto;"
                  >
                    <p
                      class="box-border leading-normal m-0 text-left"
                      style="font-weight: var(--p-weight); list-style: outside none none; quotes: auto;"
                    >
                      Fully layered dolor sit amet, consectetur adipisicing elit.
                      Facere, nobis, id expedita dolores officiis laboriosam.
                    </p>
                  </div>
                </li>
                <!-- Single Service -->
                <li
                  class="box-border flex items-start m-0 px-0 py-2 text-left"
                  style="list-style: none; quotes: auto;"
                >
                  <div
                    class="leading-6 py-0 pl-0 pr-6 text-gray-700"
                    style="list-style: outside none none; quotes: auto;"
                  >
                    <span
                      class="rounded box-border inline-block h-12 text-2xl m-0 p-0 shadow-xs text-center w-12"
                      style="line-height: 2.25; transition: all 0.3s ease 0s; list-style: outside none none; quotes: auto;"
                      ><svg
                        class="inline-block h-4 overflow-visible text-center text-purple-600 w-3"
                        aria-hidden="true"
                        focusable="false"
                        data-prefix="fas"
                        data-icon="brush"
                        role="img"
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 384 512"
                        data-fa-i2svg=""
                        style="vertical-align: -0.125em; line-height: 54px; list-style: outside none none; quotes: auto;"
                      >
                        <path
                          fill="currentColor"
                          d="M352 0H32C14.33 0 0 14.33 0 32v224h384V32c0-17.67-14.33-32-32-32zM0 320c0 35.35 28.66 64 64 64h64v64c0 35.35 28.66 64 64 64s64-28.65 64-64v-64h64c35.34 0 64-28.65 64-64v-32H0v32zm192 104c13.25 0 24 10.74 24 24 0 13.25-10.75 24-24 24s-24-10.75-24-24c0-13.26 10.75-24 24-24z"
                          class="box-border text-2xl m-0 p-0 text-purple-600"
                          style="line-height: 2.25; list-style: outside none none; quotes: auto;"
                        ></path></svg
                      ><!-- <i class="fas fa-brush"></i> --></span
                    >
                  </div>
                  <div
                    class="flex-1 leading-6 p-0 text-gray-700"
                    style="list-style: outside none none; quotes: auto;"
                  >
                    <p
                      class="box-border leading-normal m-0 text-left"
                      style="font-weight: var(--p-weight); list-style: outside none none; quotes: auto;"
                    >
                      Customizable design dolor sit amet, consectetur adipisicing
                      elit. Facere, nobis, id expedita dolores officiis laboriosam.
                    </p>
                  </div>
                </li>
                <!-- Single Service -->
                <li
                  class="box-border flex items-start m-0 px-0 py-2 text-left"
                  style="list-style: none; quotes: auto;"
                >
                  <div
                    class="leading-6 py-0 pl-0 pr-6 text-gray-700"
                    style="list-style: outside none none; quotes: auto;"
                  >
                    <span
                      class="rounded box-border inline-block h-12 text-2xl m-0 p-0 shadow-xs text-center w-12"
                      style="line-height: 2.25; transition: all 0.3s ease 0s; list-style: outside none none; quotes: auto;"
                      ><svg
                        class="inline-block h-4 overflow-visible text-center text-purple-600 w-3"
                        aria-hidden="true"
                        focusable="false"
                        data-prefix="fas"
                        data-icon="burn"
                        role="img"
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 384 512"
                        data-fa-i2svg=""
                        style="vertical-align: -0.125em; line-height: 54px; list-style: outside none none; quotes: auto;"
                      >
                        <path
                          fill="currentColor"
                          d="M192 0C79.7 101.3 0 220.9 0 300.5 0 425 79 512 192 512s192-87 192-211.5c0-79.9-80.2-199.6-192-300.5zm0 448c-56.5 0-96-39-96-94.8 0-13.5 4.6-61.5 96-161.2 91.4 99.7 96 147.7 96 161.2 0 55.8-39.5 94.8-96 94.8z"
                          class="box-border text-2xl m-0 p-0 text-purple-600"
                          style="line-height: 2.25; list-style: outside none none; quotes: auto;"
                        ></path></svg
                      ><!-- <i class="fas fa-burn"></i> --></span
                    >
                  </div>
                  <div
                    class="flex-1 leading-6 p-0 text-gray-700"
                    style="list-style: outside none none; quotes: auto;"
                  >
                    <p
                      class="box-border leading-normal m-0 text-left"
                      style="font-weight: var(--p-weight); list-style: outside none none; quotes: auto;"
                    >
                      Drop ipsum dolor sit amet, consectetur adipisicing elit.
                      Facere, nobis, id expedita dolores officiis laboriosam.
                    </p>
                  </div>
                </li>
                <!-- Single Service -->
                <li
                  class="box-border flex items-start m-0 px-0 py-2 text-left"
                  style="list-style: none; quotes: auto;"
                >
                  <div
                    class="leading-6 py-0 pl-0 pr-6 text-gray-700"
                    style="list-style: outside none none; quotes: auto;"
                  >
                    <span
                      class="rounded box-border inline-block h-12 text-2xl m-0 p-0 shadow-xs text-center w-12"
                      style="line-height: 2.25; transition: all 0.3s ease 0s; list-style: outside none none; quotes: auto;"
                      ><svg
                        class="inline-block h-4 overflow-visible text-center text-purple-600 w-4"
                        aria-hidden="true"
                        focusable="false"
                        data-prefix="fas"
                        data-icon="cart-arrow-down"
                        role="img"
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 576 512"
                        data-fa-i2svg=""
                        style="vertical-align: -0.125em; line-height: 54px; list-style: outside none none; quotes: auto;"
                      >
                        <path
                          fill="currentColor"
                          d="M504.717 320H211.572l6.545 32h268.418c15.401 0 26.816 14.301 23.403 29.319l-5.517 24.276C523.112 414.668 536 433.828 536 456c0 31.202-25.519 56.444-56.824 55.994-29.823-.429-54.35-24.631-55.155-54.447-.44-16.287 6.085-31.049 16.803-41.548H231.176C241.553 426.165 248 440.326 248 456c0 31.813-26.528 57.431-58.67 55.938-28.54-1.325-51.751-24.385-53.251-52.917-1.158-22.034 10.436-41.455 28.051-51.586L93.883 64H24C10.745 64 0 53.255 0 40V24C0 10.745 10.745 0 24 0h102.529c11.401 0 21.228 8.021 23.513 19.19L159.208 64H551.99c15.401 0 26.816 14.301 23.403 29.319l-47.273 208C525.637 312.246 515.923 320 504.717 320zM403.029 192H360v-60c0-6.627-5.373-12-12-12h-24c-6.627 0-12 5.373-12 12v60h-43.029c-10.691 0-16.045 12.926-8.485 20.485l67.029 67.029c4.686 4.686 12.284 4.686 16.971 0l67.029-67.029c7.559-7.559 2.205-20.485-8.486-20.485z"
                          class="box-border text-2xl m-0 p-0 text-purple-600"
                          style="line-height: 2.25; list-style: outside none none; quotes: auto;"
                        ></path></svg
                      ><!-- <i class="fas fa-cart-arrow-down"></i> --></span
                    >
                  </div>
                  <div
                    class="flex-1 leading-6 p-0 text-gray-700"
                    style="list-style: outside none none; quotes: auto;"
                  >
                    <p
                      class="box-border leading-normal m-0 text-left"
                      style="font-weight: var(--p-weight); list-style: outside none none; quotes: auto;"
                    >
                      Marketing chart dolor sit amet, consectetur adipisicing elit.
                      Facere, nobis, id expedita dolores officiis laboriosam.
                    </p>
                  </div>
                </li>
              </ul>
              <a
                href="#"
                class="bg-transparent border-transparent rounded-md border-none border-0 cursor-pointer inline-block font-medium text-base leading-none mx-0 mb-0 mt-6 py-4 px-8 relative shadow-none text-center text-gray-900 no-underline select-none align-middle hover:shadow-xs hover:text-blue-700 focus:shadow-xs focus:no-underline"
                style="outline: none 0px; transition: color 0.15s ease-in-out 0s, background-color 0.15s ease-in-out 0s, border-color 0.15s ease-in-out 0s, box-shadow 0.15s ease-in-out 0s; z-index: 1; quotes: auto;"
                >Learn More</a
              >
            </div>
          </div>
          <div
            class="md:block lg:flex-grow-0 lg:flex-shrink-0 lg:order-2 hidden flex-grow-0 flex-shrink-0 order-1 leading-6 m-0 max-w-full py-0 px-4 relative text-gray-700 w-full"
            style="flex-basis: 100%; quotes: auto;"
          >
            <!-- Service Thumb -->
            <div
              class="box-border my-0 mx-auto p-0 text-left"
              style="quotes: auto;"
            >
              <img
                src="assets/img/services/thumb-2.png"
                alt=""
                class="border-none h-auto leading-6 m-0 max-w-full text-left text-gray-700 align-middle"
                style="quotes: auto;"
              />
            </div>
          </div>
        </div>
      </div>
    </section>

  </div>
</template>

<script>
export default {}
</script>

<style></style>
