// const types = {
//   GOTO_NEXT: 'GOTO_NEXT',
//   BOOTSTRAP_PAGES: 'BOOTSTRAP_PAGES'
// }

export const state = () => ({
  index: 0,
  pages: []
})

export const getters = {
  index: state => state.index,
  currentPage: state => state.pages[state.index],
  isNextEnabled: state => state.index < state.pages.length - 1,
  isBackEnabled: state => state.index > 0
}

export const mutations = {
  incrementIndex: (state) => {
    state.index++
  },
  decrementIndex: (state) => {
    state.index--
  },
  setIndex: (state, index) => {
    state.index = index
  },
  bootstrapPages: (state, pages) => {
    state.pages = pages
  }
}

export const actions = {
  gotoNext: ({ commit, state }) => {
    if (state.index < state.pages.length - 1) {
      commit('incrementIndex')
    }
  },
  goBack: ({ commit, state }) => {
    if (state.index > 0) {
      commit('decrementIndex')
    }
  },
  gotoStart: ({ commit, state }) => {
    commit('setIndex', 0)
  }
}
