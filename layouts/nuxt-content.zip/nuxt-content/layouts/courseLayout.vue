<template>
  <div>
    <Navigation01 />
    <Nuxt />
    <Footer01 />
  </div>
</template>

<style>

</style>
