<template>
  <header>
    <nav class="bg-white shadow">
      <div class="container mx-auto px-6 py-6 ">
        <div class="md:flex md:items-center md:justify-start">
          <div class="flex justify-between items-center">
            <div class="text-xl font-semibold text-gray-700">
              <a
                href="#"
                class="text-gray-800 text-xl font-black hover:text-gray-700 md:text-4xl"
                >.LOGO</a
              >
            </div>

            <!-- Mobile menu button -->
            <div class="flex md:hidden">
              <button
                type="button"
                class="text-gray-500 hover:text-gray-600 focus:outline-none focus:text-gray-600"
                aria-label="toggle menu"
              >
                <svg viewBox="0 0 24 24" class="h-6 w-6 fill-current">
                  <path
                    fill-rule="evenodd"
                    d="M4 5h16a1 1 0 0 1 0 2H4a1 1 0 1 1 0-2zm0 6h16a1 1 0 0 1 0 2H4a1 1 0 0 1 0-2zm0 6h16a1 1 0 0 1 0 2H4a1 1 0 0 1 0-2z"
                  ></path>
                </svg>
              </button>
            </div>
          </div>
          <!-- Mobile Menu open: "block", Menu closed: "hidden" -->
          <div class="hidden ml-4 md:flex flex-grow justify-between">
            <div class="hidden -mx-4 md:flex md:items-center ">
              <a
                href="#"
                class="block mx-4 mt-2 md:mt-0 font-body font-bold text-xs text-gray-700 capitalize hover:text-blue-600"
                >Web developers</a
              >
              <a
                href="#"
                class="block mx-4 mt-2 md:mt-0 font-body font-bold text-xs text-gray-700 capitalize hover:text-blue-600"
                >Web Designers</a
              >
              <a
                href="#"
                class="block mx-4 mt-2 md:mt-0 font-body font-bold text-xs text-gray-700 capitalize hover:text-blue-600"
                >UI/UX Designers</a
              >
              <a
                href="#"
                class="block mx-4 mt-2 md:mt-0 font-body font-bold text-xs text-gray-700 capitalize hover:text-blue-600"
                >Contact</a
              >
            </div>

            <div class="hidden -mx-4 md:flex md:items-center ">
              <button class="bg-transparent h-10 w-10 ml-4 hover:bg-link text-link font-semibold hover:text-white py-3 px-3 border border-link hover:border-transparent rounded-full flex justify-center items-center">
                <svg class="fill-current w-4 h-4" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M5.09322 14V7.7H7.13342L7.46667 4.9H5.09322V3.5364C5.09322 2.8154 5.11287 2.1 6.18754 2.1H7.27603V0.098C7.27603 0.0679 6.34106 0 5.39518 0C3.41974 0 2.18281 1.1599 2.18281 3.29V4.9H0V7.7H2.18281V14H5.09322Z" />
                </svg>
              </button>
              <button class="bg-transparent h-10 w-10 ml-4 hover:bg-link text-link font-semibold hover:text-white py-3 px-3 border border-link hover:border-transparent rounded-full flex justify-center items-center">
                <svg class="fill-current w-6 h-6" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M12.3929 5.30232H6.62678C6.62678 5.90198 6.62678 7.10131 6.6231 7.70097H9.96443C9.83639 8.30063 9.38242 9.14016 8.74099 9.56292C8.74038 9.56232 8.73977 9.56652 8.73854 9.56592C7.88575 10.129 6.76033 10.2567 5.9247 10.0888C4.61488 9.82857 3.5783 8.87871 3.15741 7.67218C3.15986 7.67039 3.1617 7.6536 3.16354 7.6524C2.90011 6.90402 2.90011 5.90198 3.16354 5.30232H3.16293C3.50233 4.20014 4.57016 3.19451 5.88181 2.91926C6.93677 2.69559 8.12713 2.93785 9.00259 3.75699C9.11899 3.64305 10.6138 2.18347 10.7259 2.06474C7.73504 -0.643934 2.94605 0.30893 1.15409 3.80676H1.15348C1.15348 3.80676 1.15409 3.80676 1.15041 3.81336C0.263927 5.53139 0.300685 7.55585 1.15654 9.19173C1.15409 9.19353 1.15225 9.19473 1.15041 9.19653C1.92601 10.7017 3.33753 11.856 5.03821 12.2956C6.84488 12.7693 9.14411 12.4455 10.6843 11.0525C10.6849 11.0531 10.6855 11.0537 10.6861 11.0543C11.991 9.87894 12.8034 7.87667 12.3929 5.30232Z" />
                </svg>
              </button>
              <button class="bg-transparent h-10 w-10 mx-4 hover:bg-link text-link font-semibold hover:text-white py-3 px-3 border border-link hover:border-transparent rounded-full flex justify-center items-center">
                <svg class="fill-current w-6 h-6" viewBox="0 0 13 11" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M4.0885 11C8.99405 11 11.6772 6.76751 11.6772 3.0975C11.6772 2.97702 11.6772 2.85721 11.6694 2.73809C12.1914 2.3455 12.6418 1.85815 13 1.30041C12.5138 1.52513 11.9971 1.67269 11.4686 1.73767C12.025 1.39043 12.4417 0.844871 12.6412 0.201164C12.1173 0.524709 11.5447 0.752816 10.9473 0.87533C9.9372 -0.242865 8.24785 -0.297015 7.1734 0.754846C6.48115 1.43307 6.1867 2.44432 6.40185 3.40887C4.2575 3.29651 2.2594 2.24194 0.9048 0.507111C0.19695 1.77625 0.559 3.39939 1.73095 4.21435C1.3065 4.20148 0.89115 4.08236 0.52 3.86711V3.90231C0.52065 5.22424 1.4157 6.36274 2.6598 6.62469C2.2672 6.73638 1.8551 6.75262 1.456 6.67207C1.80505 7.8038 2.8067 8.57882 3.94745 8.60116C3.003 9.37415 1.83625 9.79381 0.63505 9.79246C0.42315 9.79178 0.21125 9.77892 0 9.75252C1.22005 10.5675 2.639 11 4.0885 10.998" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
    </nav>
  </header>
</template>

<script>
export default {
  name: 'Header3'
}

</script>

<style></style>
