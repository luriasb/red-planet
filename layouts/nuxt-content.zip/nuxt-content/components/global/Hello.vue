<template>
  <div>Hello</div>
</template>

<script>
export default {
  name: 'Hello'
}

</script>

<style></style>
