<template>
  <div class="mt-16">
    <div class="flex flex-wrap md:max-w-screen-xl mx-auto mb-5">
      <div class="w-full md:w-1/3 text-left">
        <h1 class="font-body text-black2 text-8xl">Display 1</h1>
      </div>
      <div class="w-full md:w-1/3 text-center">
        <h1 class="font-body text-black2 text-8xl">
          Hello World
        </h1>
      </div>
      <div class="w-full md:w-1/3 text-right">
        <h1 class="font-body text-black2 text-8xl">
          Hello World
        </h1>
      </div>
    </div>

    <div class="flex flex-wrap md:max-w-screen-xl mx-auto mb-5">
      <div class="w-full md:w-1/3 text-left">
        <h2 class="font-body text-black2 text-7xl">Display 2</h2>
      </div>
      <div class="w-full md:w-1/3 text-center">
        <h2 class="font-body text-black2 text-7xl">
          Hello World
        </h2>
      </div>
      <div class="w-full md:w-1/3 text-right">
        <h2 class="font-body text-black2 text-7xl">
          Hello World
        </h2>
      </div>
    </div>

    <div class="flex flex-wrap md:max-w-screen-xl mx-auto mb-5">
      <div class="w-full md:w-1/3 text-left">
        <h2 class="font-body text-black2 text-6xl">Display 3</h2>
      </div>
      <div class="w-full md:w-1/3 text-center">
        <h2 class="font-body text-black2 text-6xl">
          Hello World
        </h2>
      </div>
      <div class="w-full md:w-1/3 text-right">
        <h2 class="font-body text-black2 text-6xl">
          Hello World
        </h2>
      </div>
    </div>

    <div class="flex flex-wrap md:max-w-screen-xl mx-auto mb-5">
      <div class="w-full md:w-1/3 text-left">
        <h2 class="font-body text-black2 text-5xl">Heading 1</h2>
      </div>
      <div class="w-full md:w-1/3 text-center">
        <h2 class="font-body text-black2 text-5xl">
          Hello World
        </h2>
      </div>
      <div class="w-full md:w-1/3 text-right">
        <h2 class="font-body text-black2 text-5xl">
          Hello World
        </h2>
      </div>
    </div>

    <div class="flex flex-wrap md:max-w-screen-xl mx-auto mb-5">
      <div class="w-full md:w-1/3 text-left">
        <h2 class="font-body text-black2 text-4xl">Heading 2</h2>
      </div>
      <div class="w-full md:w-1/3 text-center">
        <h2 class="font-body text-black2 text-4xl">
          Hello World
        </h2>
      </div>
      <div class="w-full md:w-1/3 text-right">
        <h2 class="font-body text-black2 text-4xl">
          Hello World
        </h2>
      </div>
    </div>

    <div class="flex flex-wrap md:max-w-screen-xl mx-auto mb-5">
      <div class="w-full md:w-1/3 text-left">
        <h2 class="font-body text-black2 text-3xl">Heading 3</h2>
      </div>
      <div class="w-full md:w-1/3 text-center">
        <h2 class="font-body text-black2 text-3xl">
          Hello World
        </h2>
      </div>
      <div class="w-full md:w-1/3 text-right">
        <h2 class="font-body text-black2 text-3xl">
          Hello World
        </h2>
      </div>
    </div>

    <div class="flex flex-wrap md:max-w-screen-xl mx-auto mb-5">
      <div class="w-full md:w-1/3 text-left">
        <h2 class="font-body text-black2 text-2xl">Heading 4</h2>
      </div>
      <div class="w-full md:w-1/3 text-center">
        <h2 class="font-body text-black2 text-2xl">
          Hello World
        </h2>
      </div>
      <div class="w-full md:w-1/3 text-right">
        <h2 class="font-body text-black2 text-2xl">
          Hello World
        </h2>
      </div>
    </div>

    <div class="flex flex-wrap md:max-w-screen-xl mx-auto mb-5">
      <div class="w-full md:w-1/3 text-left">
        <h2 class="font-body text-black2 text-xl">Heading 5</h2>
      </div>
      <div class="w-full md:w-1/3 text-center">
        <h2 class="font-body text-black2 text-xl">
          Hello World
        </h2>
      </div>
      <div class="w-full md:w-1/3 text-right">
        <h2 class="font-body text-black2 text-xl">
          Hello World
        </h2>
      </div>
    </div>

    <div class="flex flex-wrap md:max-w-screen-xl mx-auto mb-5">
      <div class="w-full md:w-1/3 text-left">
        <h2 class="font-body text-black2 text-lg">Heading 6</h2>
      </div>
      <div class="w-full md:w-1/3 text-center">
        <h2 class="font-body text-black2 text-lg">
          Hello World
        </h2>
      </div>
      <div class="w-full md:w-1/3 text-right">
        <h2 class="font-body text-black2 text-lg">
          Hello World
        </h2>
      </div>
    </div>

    <div class="flex flex-wrap md:max-w-screen-xl mx-auto mb-5">
      <div class="w-full md:w-1/3 text-left">
        <h2 class="font-body text-black2 text-base">Body</h2>
      </div>
      <div class="w-full md:w-1/3 text-center">
        <h2 class="font-body text-black2 text-base">
          Hello World
        </h2>
      </div>
      <div class="w-full md:w-1/3 text-right">
        <h2 class="font-body text-black2 text-base">
          Hello World
        </h2>
      </div>
    </div>

  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
