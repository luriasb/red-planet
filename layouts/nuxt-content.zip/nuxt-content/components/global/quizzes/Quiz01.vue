<template>
  <div class="px-4 py-16 mx-auto sm:max-w-xl md:max-w-full lg:max-w-screen-xl md:px-24 lg:px-8 lg:py-20">
    <div class="grid gap-10 row-gap-8 lg:grid-cols-5">
      <div class="lg:col-span-2">
        <p class="mb-2 text-xs font-semibold tracking-wide text-gray-600 uppercase">
          <!-- {{ quiz.created_at}} -->
        </p>
        <div class="mb-3">
          <p class="font-sans text-xl font-extrabold leading-none tracking-tight lg:text-4xl xl:text-5xl">
            {{ quiz.title }}
          </p>
        </div>
        <p class="mb-4 text-base text-gray-700 md:text-lg">
          {{ quiz.instructions }}
        </p>
        <div class="flex justify-center">
          <button class="inline-flex text-white bg-indigo-500 border-0 py-2 px-6 focus:outline-none disabled:opacity-50  hover:bg-indigo-600 rounded text-lg" :disabled="status !== 'start'" @click="start()">Start</button>
        </div>
      </div>
      <div class="flex flex-col space-y-8 lg:col-span-3" v-if="questions" v-show="status == 'progress'">
        <div class="border-b py-4">
          <div class="uppercase tracking-wide text-xs font-bold text-gray-500 mb-1 leading-tight"></div>
          <div class="flex flex-col md:flex-row md:items-center md:justify-between">
            <div class="flex-1">
              <div x-show="step === 1">
                <div class="text-lg font-bold text-gray-700 leading-tight">Question {{ index + 1 }} of {{ questions.length }} </div>
              </div>
            </div>

            <div class="flex items-center md:w-64">
              <div class="w-full bg-white rounded-full mr-2">
                <div class="rounded-full bg-green-500 text-xs leading-none h-2 text-center text-white" :style="'width: '+ parseInt((index + 1) / questions.length * 100) +'%'"></div>
              </div>
              <div class="text-xs w-10 text-gray-600" > {{ parseInt((index + 1) / questions.length * 100) +'%' }}</div>
            </div>
          </div>
        </div>
        <div v-for="(question, i) in questions" :key="question.id" v-show="index == i">
          <div class="mb-3">
            <p class="font-sans text-xl font-extrabold leading-none tracking-tight lg:text-2xl">
              {{ question.text }}
            </p>
          </div>
          <div class="flex flex-col">
            <label class="inline-flex items-center mb-4" for="option1" >
              <input type="radio" class="form-radio h-5 w-5 text-gray-600" id="option1" value="1" v-model="answers[index]" ><span class="ml-2 text-base text-gray-700 md:text-lg">{{ question.option_1 }}</span>
            </label>
            <label class="inline-flex items-center mb-4" for="option2" >
              <input type="radio" class="form-radio h-5 w-5 text-gray-600" id="option2" value="2" v-model="answers[index]" ><span class="ml-2 text-base text-gray-700 md:text-lg">{{ question.option_2 }}</span>
            </label>
            <label class="inline-flex items-center mb-4" for="option3" >
              <input type="radio" class="form-radio h-5 w-5 text-gray-600" id="option3" value="3" v-model="answers[index]" ><span class="ml-2 text-base text-gray-700 md:text-lg">{{ question.option_3 }}</span>
            </label>
          </div>
        </div>
        <div class="flex flex-row-reverse justify-between">
          <button class="inline-flex text-white bg-indigo-500 disabled:opacity-50 border-0 py-2 px-6 focus:outline-none hover:bg-indigo-600 rounded text-lg" :disabled="status !== 'progress' || answers[index] == 0" @click="next()" v-if="index != questions.length - 1">Next</button>
          <button class="inline-flex text-white bg-indigo-500 disabled:opacity-50 border-0 py-2 px-6 focus:outline-none hover:bg-indigo-600 rounded text-lg" :disabled="status !== 'progress' || answers[index] == 0 " @click="evaluate()" v-if="index == questions.length - 1">Evaluate</button>
        </div>
      </div>
      <div class="flex flex-col space-y-8 lg:col-span-3" v-if="questions" v-show="status == 'finished'">
        <div class="mb-3"  v-if="status == 'finished'">
          <p class="font-sans text-xl font-bold text-center" v-if="result >= 8">
            ¡Felicidades! <br>
            Tu calificación fue:
          </p>
          <p class="font-sans text-xl font-bold text-center" v-else>
            ¡Lo sentimos! <br>
            Tu calificación fue:
          </p>
          <p class="font-sans text-xl font-extrabold leading-none tracking-tight lg:text-4xl xl:text-5xl text-center">
            {{ result }}
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    questions: {
      type: Array,
      default: () => { return [] }
    },
    quiz: {
      type: Object,
      default: () => { return {} }
    }
  },
  data () {
    return {
      status: 'start',
      index: 0,
      answers: [],
      result: 0
    }
  },

  methods: {
    start () {
      this.status = 'progress'
      this.answers = new Array(this.questions.length)
      this.answers.fill(0)
    },
    next () {
      if (this.index < this.questions.length) {
        this.index++
      }
    },
    setOption (option) {
      this.answers[this.index] = option
    },
    evaluate () {
      this.status = 'finished'
      const that = this
      this.result = this.answers.reduce((a, v, i) => {
        console.log(that.questions[i].correct)
        return (v == that.questions[i].correct) ? a + 1 : 0
      }, 0)
    }
  }
}
</script>

<style>

</style>
