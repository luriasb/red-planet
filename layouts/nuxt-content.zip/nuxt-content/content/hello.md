---
title: Getting started
description: 'Empower your NuxtJS application with @nuxt/content module: write in a content/ directory and fetch your Markdown, JSON, YAML and CSV files through a MongoDB like API, acting as a Git-based Headless CMS.'
title1: Este es mi propio
---



<page-hero :title1="title1" title2="componente"></page-hero>

<para-image></para-image>

<page-footer></page-footer>