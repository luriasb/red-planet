---
index: 2.0
title: Curso para hacer algo
description: 'Empower your NuxtJS application with @nuxt/content module: write in a content/ directory and fetch your Markdown, JSON, YAML and CSV files through a MongoDB like API, acting as a Git-based Headless CMS.'


quiz:
    title: El gran quiz
    instructions: Selecciona la respuesta que consideres correcta.
    random: true

questions:
-
    id: 1
    text: ¿Quién participa en el recorrido de la entrega de unidad?
    correct: 1
    option_1: Store Planning, Construcciones y Gerencia de la unidad.
    option_2: Resurtido, Compras y Capacitación.
    option_3: Todos los(as) asociados(as) de la tienda.
-
    id: 2
    text: ¿Qué área da seguimiento a toda la implementación de la nueva unidad?
    correct: 1
    option_1: Store Planning.
    option_2: Recursos Humanos.
    option_3: Logística.
-
    id: 3
    text: ¿Cómo se llaman los equipos que sirven para conectar las terminales portátiles TC70?
    correct: 1
    option_1: Antenas de radiofrecuencia AXP.
    option_2: Postes de comunicación.
    option_3: Telxon.
-
    id: 4
    text: ¿Cuál es el primer material que llega en la toma de posesión de la unidad?
    correct: 1
    option_1: Consumos Internos (Scope).
    option_2: Material de Capacitación.
    option_3: Material de Seguridad.
-
    id: 5
    text: Documento que indica el acomodo de la mercancía en los muebles.
    correct: 1
    option_1: Planograma.
    option_2: Mapa de carga.
    option_3: Fichas técnicas.
-
    id: 6
    text: Documento que permite conocer la distribución de las áreas en todo el inmueble.
    correct: 1
    option_1: LayOut.
    option_2: Checklist.
    option_3: Time line.
-
    id: 7
    text: ¿Con qué anticipación se señaliza la mercancía de la unidad?
    correct: 1
    option_1: Dos o tres días antes de la apertura.
    option_2: El primer día de la toma de posesión.
    option_3: Cuando se instale el sistema.
-
    id: 8
    text: Sistema que se habilita para el programa NINJA en Piso de Venta.
    correct: 1
    option_1: Aisle Locator.
    option_2: SMART.
    option_3: People Soft.
-
    id: 9
    text: ¿Cuántas pruebas se realizan en línea de cajas para probar los sistemas?
    correct: 1
    option_1: 3 pruebas - barrido de mercancía, tarjetas bancarias y de Pin Pad.
    option_2: 1 prueba - la de Sensor Matić.
    option_3: 2 pruebas - de NCR y de Datalogic.
-
    id: 10
    text: Área encargada de garantizar el abasto de la mercancía en apertura.
    correct: 1
    option_1: Resurtido Aperturas.
    option_2: Eficiencia Operativa.
    option_3: Gerencia de la unidad.

---


<Quiz01 :quiz="quiz" :questions="questions"></Quiz01>