---
index: 0.0
title: Finanzas personales
description: 'La palabra finanzas parece hacer referencia a términos complejos relacionados con economía, la bolsa de valores, inversionistas, matemáticas y administración. Sin embargo, las finanzas se influyen en todo y nuestra vida diaria no es la excepción, de ahí que surja el concepto de finanzas personales.'
title1: Este es mi propio
image01: /course/photo01.jpeg
button: Start
---


<!--more-->

<HeroA01 :title="title" :description="description" ></HeroA01>