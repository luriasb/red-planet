---
index: 1.0
title: Curso para hacer algo
description: 'Empower your NuxtJS application with @nuxt/content module: write in a content/ directory and fetch your Markdown, JSON, YAML and CSV files through a MongoDB like API, acting as a Git-based Headless CMS.'
title1: Este es mi propio
image01: /course/photo01.jpeg
button: Start

steps:
  - name: PASO 1
    description: 'Esta es la descripción del paso 1'
  - name: PASO 2
    description: 'Esta es la descripción del paso 2'
  - name: PASO 3
    description: 'Esta es la descripción del paso 3'
  - name: PASO 4
    description: 'Esta es la descripción del paso 4'

image02: /course/photo02.jpeg
---


<hero-01 :title="title" :description="description" :image="image01" :button="button"></hero-01>